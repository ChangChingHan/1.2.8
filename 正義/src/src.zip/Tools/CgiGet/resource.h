//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CgiGet.rc
//
#define IDD_CGIGET_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_LIST_MSG                    1000
#define IDC_EDIT_IP1                    1001
#define IDC_EDIT_PORT1                  1002
#define IDC_EDIT_USERNAME1              1003
#define IDC_EDIT_PASSWORD1              1004
#define IDC_EDIT_INFO1                  1005
#define IDC_EDIT_IP2                    1006
#define IDC_EDIT_PORT2                  1007
#define IDC_EDIT_USERNAME2              1008
#define IDC_EDIT_PASSWORD2              1009
#define IDC_EDIT_INFO2                  1010
#define IDC_BUTTON_GET                  1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
