//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ͪ� Include �ɮסC
// �� QueryCGI.rc �ϥ�
//
#define IDD_QUERYCGI_DIALOG             102
#define IDD_MAIN_DIALOG                 102
#define IDR_HTML_SETTINGDLG             103
#define IDR_MAINFRAME                   128
#define IDD_SETTING_DIALOG              129
#define IDC_BTN_QUERY                   1000
#define IDC_LIST_MSG                    1001
#define IDC_LIST1                       1002
#define IDC_BTN_MODIFY                  1002
#define IDC_LIST2                       1003
#define IDC_EDT_PORT                    1004
#define IDC_EDT_IP                      1005
#define IDC_EDT_USER                    1006
#define IDC_EDT_PW                      1007
#define IDC_BTN_ADD                     1008
#define IDC_BTN_REMOVE                  1009
#define IDC_STATIC_AUTH                 1009
#define IDC_IPADDRESS1                  1010
#define IDC_IPADDRESS                   1010
#define IDC_EDIT1                       1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
